﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectosNoticiasJuan.Clases
{
    public class Usuario
    {
        public string Nombre;
        public string Apellido;
        public string PerfilDescripcion;
        public int UsuarioID;
        public int PerfilID;
    }
}
